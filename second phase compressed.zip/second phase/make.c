#include <stdio.h>
#include <stdlib.h>
#include "user.h"
#include "grocery.h"

int main() {
    User user;
    ShoppingList shoppingList;
    int choice;
    int quantity;

    printf("Welcome to the Grocery Store!\n");

    createUser(&user);

    char input_username[20];
    char input_password[20];
    printf("Enter your username: ");
    scanf("%19s", input_username);
    printf("Enter your password: ");
    scanf("%19s", input_password);

    if (loginUser(&user, input_username, input_password)) {
        printf("Login successful. Welcome, %s!\n", user.username);

        initShoppingList(&shoppingList);

        while (1) {
            displayMenu();
            printf("Enter your choice (1-5): ");
            scanf("%d", &choice);

            if (choice == 5) {
                printf("\nThank you for shopping with us, %s!\n", user.username);
                break;
            }

            if (choice < 1 || choice > 4) {
                printf("Invalid choice!\n");
                continue;
            }

            printf("Enter quantity: ");
            scanf("%d", &quantity);

            if (quantity <= 0) {
                printf("Invalid quantity!\n");
                continue;
            }

            addToShoppingList(&shoppingList, choice, quantity);
        }

        shoppingList.total = calculateTotal(&shoppingList);
        printf("Total bill: ₹%.2f\n", shoppingList.total);

        freeShoppingList(&shoppingList);
    } else {
        printf("Invalid username or password. Please try again.\n");
    }

    return 0;
}
