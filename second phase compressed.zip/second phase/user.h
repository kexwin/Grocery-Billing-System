#ifndef USER_H
#define USER_H

typedef struct {
    char username[20];
    char password[20];
    int customerId;
} User;

void createUser(User *user);
int loginUser(const User *user, const char *username, const char *password);

#endif /* USER_H */
