#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "user.h"

void createUser(User *user) {
    printf("Set your username: ");
    scanf("%s", user->username);
    printf("Set your password: ");
    scanf("%s", user->password);
    printf("Enter your customer ID: ");
    scanf("%d", &user->customerId);
}

int loginUser(const User *user, const char *username, const char *password) {
    return (strcmp(user->username, username) == 0 && strcmp(user->password, password) == 0);
}
