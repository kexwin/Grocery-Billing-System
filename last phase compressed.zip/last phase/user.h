#ifndef USER_H
#define USER_H

#define MAX_USERS 10
#define FILENAME "users.txt"

typedef struct {
    char username[20];
    char password[20];
} User;

void displayMenu();
void saveUsers(User users[], int userCount);
int loadUsers(User users[]);
void searchUser(User users[], int userCount);

#endif
