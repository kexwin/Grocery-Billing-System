#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "user.h"

void displayMenu(){
    printf("-------------------------------------------\n");
    printf("|         Welcome to Grocery Store        |\n");
    printf("-------------------------------------------\n");
    printf("| 1. Rice   - Rs 50                       |\n");
    printf("| 2. Bread  - Rs 20                       |\n");
    printf("| 3. Milk   - Rs 25                       |\n");
    printf("| 4. Eggs   - Rs 15                       |\n");
    printf("| 5. Exit                                 |\n");
    printf("-------------------------------------------\n");
}

void saveUsers(User users[], int userCount){
    FILE *file = fopen(FILENAME, "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        exit(1);
    }
    for (int i = 0; i < userCount; i++){
        fprintf(file, "%s %s\n", users[i].username, users[i].password);
    }
    fclose(file);
}

int loadUsers(User users[]){
    FILE *file = fopen(FILENAME, "r");
    if (file == NULL) {
        return 0;
    }
    int userCount = 0;
    while (fscanf(file, "%s %s", users[userCount].username, users[userCount].password) != EOF && userCount < MAX_USERS){
        userCount++;
    }
    fclose(file);
    return userCount;
}

void searchUser(User users[], int userCount){
    char searchUsername[20];
    printf("Enter username to search: ");
    scanf("%s", searchUsername);

    for (int i = 0; i < userCount; i++) {
        if (strcmp(searchUsername, users[i].username) == 0){
            printf("User found: %s\n", users[i].username);
            return;
        }
    }
    printf("User not found.\n");
}
