#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "user.h"

int main(){
    User users[MAX_USERS];
    int userCount = loadUsers(users);
    int choice;
    int quantity;
    float totalBill = 0;
    int isLoggedIn = 0;

    printf("Welcome to the Grocery Billing System!\n");

    while (!isLoggedIn){
        printf("Choose an option:\n");
        printf("1. Login\n");
        printf("2. Create an account\n");
        printf("3. Search for a user\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice){
            case 1: {
                char enteredUsername[20];
                char enteredPassword[20];
                printf("Enter your username: ");
                scanf("%s", enteredUsername);
                printf("Enter your password: ");
                scanf("%s", enteredPassword);

                for (int i = 0; i < userCount; i++){
                    if (strcmp(enteredUsername, users[i].username) == 0 && strcmp(enteredPassword, users[i].password) == 0){
                        printf("Login successful!\n");
                        isLoggedIn = 1;
                        break;
                    }
                }

                if (!isLoggedIn){
                    printf("Invalid username or password!\n");
                }
                break;
            }
            case 2:
                if (userCount < MAX_USERS){
                    printf("Enter your desired username: ");
                    scanf("%s", users[userCount].username);
                    printf("Enter your desired password: ");
                    scanf("%s", users[userCount].password);
                    printf("Account created successfully!\n");
                    userCount++;
                    saveUsers(users, userCount);
                } else {
                    printf("Maximum number of users reached!\n");
                }
                break;

            case 3:
                searchUser(users, userCount);
                break;

            default:
                printf("Invalid choice!\n");
        }
    }

    while (1){
        displayMenu();
        printf("Enter your choice (1-5): ");
        scanf("%d", &choice);

        if (choice == 5){
            printf("Thank you for shopping with us!\n");
            break;
        }

        switch (choice){
            case 1:
                printf("Enter quantity: ");
                scanf("%d", &quantity);
                totalBill += quantity * 50;
                break;
            case 2:
                printf("Enter quantity: ");
                scanf("%d", &quantity);
                totalBill += quantity * 20;
                break;
            case 3:
                printf("Enter quantity: ");
                scanf("%d", &quantity);
                totalBill += quantity * 25;
                break;
            case 4:
                printf("Enter quantity: ");
                scanf("%d", &quantity);
                totalBill += quantity * 15;
                break;
            default:
                printf("Invalid choice!\n");
        }
    }

    printf("Total bill: Rs %.2f\n", totalBill);

    return 0;
}
